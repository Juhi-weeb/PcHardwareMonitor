PC Hardware Monitor
=========
## A desktop widget that displays CPU, GPU and other hardware information.
<img src="https://raw.githubusercontent.com/TylerSwann/PCHardwareMonitor/master/PCHardwareMonitor/screenshots/screenshot6.PNG" width=700 height=auto />
<img src="https://raw.githubusercontent.com/TylerSwann/PCHardwareMonitor/master/PCHardwareMonitor/screenshots/screenshot5.PNG" width=700 height=auto />

## Customizable

*	### Change the color of any part of the widgets as well as their font.

<img src="https://raw.githubusercontent.com/TylerSwann/PCHardwareMonitor/master/PCHardwareMonitor/screenshots/customizationScreenShots.png" width=1200 height=auto />

<img src="https://raw.githubusercontent.com/TylerSwann/PCHardwareMonitor/master/PCHardwareMonitor/screenshots/settingsScreenShots.png" width=1200 height=auto />

*	### Settings window can be accessed by clicking the red heart in the notification area on the taskbar

<img src="https://raw.githubusercontent.com/TylerSwann/PCHardwareMonitor/master/PCHardwareMonitor/screenshots/screenshot11.PNG" width=200 height=auto />
